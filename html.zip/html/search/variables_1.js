var searchData=
[
  ['cites',['cites',['../class_biblioteca.html#a9ec415a8b3c2c6fa6359ce21ef084208',1,'Biblioteca']]]
];
