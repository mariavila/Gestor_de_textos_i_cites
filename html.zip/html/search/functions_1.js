var searchData=
[
  ['biblioteca',['Biblioteca',['../class_biblioteca.html#a5e12ea4e7a4edb14d210a41708fc1c10',1,'Biblioteca']]],
  ['buscar_5fconsecutives',['buscar_consecutives',['../class_frase.html#ab70fce425ec1e0ba313946743c831bf4',1,'Frase']]],
  ['buscar_5fparaules_5ftext',['buscar_paraules_text',['../class_text.html#a78c34fc4d03ea44d8deb279113ed4292',1,'Text']]]
];
