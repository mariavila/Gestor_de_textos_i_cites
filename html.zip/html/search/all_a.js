var searchData=
[
  ['p',['P',['../_frase_8cc.html#a67be55f705ba1488c1ee9c887845efbe',1,'P():&#160;Frase.cc'],['../_frase_8hh.html#a67be55f705ba1488c1ee9c887845efbe',1,'P():&#160;Frase.hh']]],
  ['paraules',['paraules',['../class_frase.html#a0f287e91b701d09c2c3adaf19fbe16cb',1,'Frase']]],
  ['program_2ecc',['program.cc',['../program_8cc.html',1,'']]],
  ['psd',['PSD',['../_taula_8cc.html#a95b3c9d44cb32bca6cc9ae6378493217',1,'PSD():&#160;Taula.cc'],['../_taula_8hh.html#a95b3c9d44cb32bca6cc9ae6378493217',1,'PSD():&#160;Taula.hh']]],
  ['pti',['PTI',['../_biblioteca_8cc.html#a8307deed0285d815f07fc77abbdc6f26',1,'PTI():&#160;Biblioteca.cc'],['../_biblioteca_8hh.html#a8307deed0285d815f07fc77abbdc6f26',1,'PTI():&#160;Biblioteca.hh']]]
];
