var searchData=
[
  ['separar_5fexpressio',['separar_expressio',['../_text_8cc.html#a9a08bb723219e1645dde8cd1fcf13f76',1,'Text.cc']]],
  ['separar_5fparaules',['separar_paraules',['../_text_8cc.html#aa182ed5af1f98b254b3a8cb3f70de36b',1,'Text.cc']]],
  ['set_5fparaules_5ftext',['set_paraules_text',['../class_text.html#aed458c64898a0a4f394de7b701ea7f40',1,'Text']]]
];
