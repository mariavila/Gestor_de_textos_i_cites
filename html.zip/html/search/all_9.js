var searchData=
[
  ['ordenacio',['ordenacio',['../_taula_8cc.html#a269480a363155fa053119a324d298e71',1,'Taula.cc']]]
];
