var searchData=
[
  ['taula',['Taula',['../class_taula.html#a11165734927af739d17c3608b7b48bcc',1,'Taula']]],
  ['text',['Text',['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text']]],
  ['textos_5fautor_5fbiblio',['textos_autor_biblio',['../class_biblioteca.html#a14404ef57f0598b24bedc8977f1995a7',1,'Biblioteca']]],
  ['titol_5ftext',['titol_text',['../class_text.html#a7badc705f2a5fdce33a1c22026ad6d81',1,'Text']]],
  ['triar_5ftext_5fbiblio',['triar_text_biblio',['../class_biblioteca.html#a86bcd936fd7671f00d2345b7c930c7b3',1,'Biblioteca']]]
];
