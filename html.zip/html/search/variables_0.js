var searchData=
[
  ['aparicions_5fstring',['aparicions_string',['../class_taula.html#ae62a770801f13c4308e79482710c7a21',1,'Taula']]],
  ['autor_5fdel_5ftext',['autor_del_text',['../class_text.html#a2555f7ce9f6ec4eb449a63d765e11428',1,'Text']]]
];
