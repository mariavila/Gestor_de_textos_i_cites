var searchData=
[
  ['eliminar_5fcita_5fbiblio',['eliminar_cita_biblio',['../class_biblioteca.html#a9c310cda012fbc9d5b286d48f0f8557a',1,'Biblioteca']]],
  ['eliminar_5ftext_5fbiblio',['eliminar_text_biblio',['../class_biblioteca.html#a87cf5e3de05fa5081d328a3622c8a457',1,'Biblioteca']]],
  ['escriure_5fbiblio',['escriure_biblio',['../class_biblioteca.html#a50d52aee9159520eba3f765cf0841047',1,'Biblioteca']]],
  ['escriure_5ffrase',['escriure_frase',['../class_frase.html#a592004c88d4af279bc32a1781caf524e',1,'Frase']]],
  ['escriure_5ffrase_5fi_5ftext',['escriure_frase_i_text',['../class_text.html#a19d0b5fbf8eb864fa00256789a5e2da0',1,'Text']]],
  ['escriure_5ffrases_5fbiblio',['escriure_frases_biblio',['../class_biblioteca.html#afddb5f999ab2706dd2e722e52a443d77',1,'Biblioteca']]],
  ['escriure_5ftaula_5ffreq',['escriure_taula_freq',['../class_biblioteca.html#a01ed2d2551c081e69b7e267bab61d0f1',1,'Biblioteca::escriure_taula_freq()'],['../class_taula.html#a5dc9da4b568a15495c6b869e605dc873',1,'Taula::escriure_taula_freq()']]],
  ['escriure_5ftext',['escriure_text',['../class_text.html#af5b1fa6be3615fdba030ba5c57731b8b',1,'Text']]],
  ['escriure_5ftotes_5fcites',['escriure_totes_cites',['../class_biblioteca.html#a535efc13b8847a145194de80bd1023f5',1,'Biblioteca']]]
];
