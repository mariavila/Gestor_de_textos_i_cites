var searchData=
[
  ['frase',['Frase',['../class_frase.html#a6af6ccf07cac65950917bc81f5e03c95',1,'Frase::Frase()'],['../class_frase.html#a32985d4115726aaa914cc93cb0afce6a',1,'Frase::Frase(Frase const &amp;copia)']]],
  ['frases_5fconsecutives_5ftext',['frases_consecutives_text',['../class_text.html#a95db9ef142bee8175c11e899df54110e',1,'Text']]],
  ['frases_5fconsecutives_5ftriat',['frases_consecutives_triat',['../class_biblioteca.html#a702d23e0b7ad5a6cdec9270592b35c5f',1,'Biblioteca']]],
  ['frases_5fexpressio_5ftext',['frases_expressio_text',['../class_text.html#af2f48f85c426047232fdb930a49b8c96',1,'Text']]],
  ['frases_5fexpressio_5ftext_5frecurs',['frases_expressio_text_recurs',['../class_text.html#abdab2f434fbabe87b7011edfdd3a30bd',1,'Text']]],
  ['frases_5fexpressio_5ftriat',['frases_expressio_triat',['../class_biblioteca.html#a3fde0ed31ba33cefddd1dad55b80d74f',1,'Biblioteca']]],
  ['frases_5ftext_5fx',['frases_text_x',['../class_text.html#aed6636841aacd0355b0a9d1aa26b8390',1,'Text']]]
];
