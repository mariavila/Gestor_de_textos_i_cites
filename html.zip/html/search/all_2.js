var searchData=
[
  ['cita_5freferencia',['cita_referencia',['../class_biblioteca.html#a11e3337ebc2b781715bf7b2d6083d8b0',1,'Biblioteca']]],
  ['cites',['cites',['../class_biblioteca.html#a9ec415a8b3c2c6fa6359ce21ef084208',1,'Biblioteca']]],
  ['cites_5fautor',['cites_autor',['../class_biblioteca.html#a9d8ab7262c4e6875bf59dca53218c372',1,'Biblioteca']]],
  ['cites_5ftriat',['cites_triat',['../class_biblioteca.html#a67c6462dbd0d64f93d1413f8ed6fb2ee',1,'Biblioteca']]],
  ['convertir_5ffrase',['convertir_frase',['../class_frase.html#a8d17fb72ab9aa7f831a929719bcb6ac7',1,'Frase']]],
  ['crear_5ftaula_5faparicions_5ftext',['crear_taula_aparicions_text',['../class_text.html#a2fe8af84ef77f8090dc6559a93658c43',1,'Text']]],
  ['crear_5fvector',['crear_vector',['../class_taula.html#aa203c64cb51909f9eb9841b5b61c189c',1,'Taula']]]
];
