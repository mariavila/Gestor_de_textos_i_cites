var searchData=
[
  ['num_5fparaules_5fdel_5ftext',['num_paraules_del_text',['../class_text.html#a127c1c1275ca1c9e1b9aa7f261d97ff5',1,'Text']]]
];
