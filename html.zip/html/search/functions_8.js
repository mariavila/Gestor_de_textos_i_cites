var searchData=
[
  ['num_5ffrases_5ftext',['num_frases_text',['../class_text.html#ab149a11ae2f0498909fc641420b6827c',1,'Text']]],
  ['num_5ffrases_5ftriat',['num_frases_triat',['../class_biblioteca.html#a735ae3730786ea5d92430809adefaa0b',1,'Biblioteca']]],
  ['num_5fparaules_5ffrase',['num_paraules_frase',['../class_frase.html#acd6adf9f600e2617a976fb4dfc2e8597',1,'Frase']]],
  ['num_5fparaules_5ftext',['num_paraules_text',['../class_text.html#adfa31fa87996363e8f5fbdacf782f91e',1,'Text']]],
  ['num_5fparaules_5ftriat',['num_paraules_triat',['../class_biblioteca.html#a16916e8fb0420d33610e7ae01c49e255',1,'Biblioteca']]]
];
