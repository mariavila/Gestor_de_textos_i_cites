var searchData=
[
  ['taula',['Taula',['../class_taula.html',1,'Taula'],['../class_taula.html#a11165734927af739d17c3608b7b48bcc',1,'Taula::Taula()']]],
  ['taula_2ecc',['Taula.cc',['../_taula_8cc.html',1,'']]],
  ['taula_2ehh',['Taula.hh',['../_taula_8hh.html',1,'']]],
  ['text',['Text',['../class_text.html',1,'Text'],['../class_text.html#ab3e26143fccc52699bcc5149cae852bc',1,'Text::Text()']]],
  ['text_2ecc',['Text.cc',['../_text_8cc.html',1,'']]],
  ['text_2ehh',['Text.hh',['../_text_8hh.html',1,'']]],
  ['text_5fvalid',['text_valid',['../class_biblioteca.html#a9d0f237816a4c181bb8c29a71f0a9253',1,'Biblioteca']]],
  ['textos_5fautor_5fbiblio',['textos_autor_biblio',['../class_biblioteca.html#a14404ef57f0598b24bedc8977f1995a7',1,'Biblioteca']]],
  ['textos_5fbiblio',['textos_biblio',['../class_biblioteca.html#af5164bcce1f70a80a06d82f0b78c9f07',1,'Biblioteca']]],
  ['titol_5fdel_5ftext',['titol_del_text',['../class_text.html#a877866f5662b50ffecdb07185e69a031',1,'Text']]],
  ['titol_5ftext',['titol_text',['../class_text.html#a7badc705f2a5fdce33a1c22026ad6d81',1,'Text']]],
  ['triar_5ftext_5fbiblio',['triar_text_biblio',['../class_biblioteca.html#a86bcd936fd7671f00d2345b7c930c7b3',1,'Biblioteca']]],
  ['triat',['triat',['../class_biblioteca.html#aa6e859bba67d97df2ac80da0ae4744f0',1,'Biblioteca']]]
];
