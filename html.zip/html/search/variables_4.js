var searchData=
[
  ['paraules',['paraules',['../class_frase.html#a0f287e91b701d09c2c3adaf19fbe16cb',1,'Frase']]]
];
