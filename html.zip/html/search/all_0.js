var searchData=
[
  ['afegir_5fautor',['afegir_autor',['../class_text.html#a11077526d448622c02e70808c175ab82',1,'Text']]],
  ['afegir_5fcita',['afegir_cita',['../class_biblioteca.html#a5cfe3162f6275e38dd4ac1727a5b74ed',1,'Biblioteca']]],
  ['afegir_5ffrase_5fcontingut',['afegir_frase_contingut',['../class_text.html#af8b7f2b165022b71bac6321dc755843b',1,'Text']]],
  ['afegir_5ftitol',['afegir_titol',['../class_text.html#a6912a308fe0b6285909e2b3d1d623b11',1,'Text']]],
  ['afegir_5fun',['afegir_un',['../class_taula.html#a662f3e62d0f3358ae761ca1d219c9906',1,'Taula']]],
  ['aparicions_5fstring',['aparicions_string',['../class_taula.html#ae62a770801f13c4308e79482710c7a21',1,'Taula']]],
  ['autor_5fbiblio',['autor_biblio',['../class_biblioteca.html#a906e828dab4c5a4a73d1d9dec5d2727e',1,'Biblioteca']]],
  ['autor_5fdel_5ftext',['autor_del_text',['../class_text.html#a2555f7ce9f6ec4eb449a63d765e11428',1,'Text']]],
  ['autor_5ftext',['autor_text',['../class_text.html#a99e843f00269f32461e57890ac5f0315',1,'Text']]],
  ['autor_5ftriat',['autor_triat',['../class_biblioteca.html#ab73ba446bf29097b1a27f233d5ac9569',1,'Biblioteca']]]
];
