var searchData=
[
  ['iguals',['iguals',['../class_frase.html#a3eacb8c7bb8c696acfb9751bc34f2696',1,'Frase']]],
  ['info_5ftriat',['info_triat',['../class_biblioteca.html#af1acace5df4f15ed7275e4dab75235c5',1,'Biblioteca']]],
  ['inicials_5fautor_5ftriat',['inicials_autor_triat',['../class_biblioteca.html#a968b7d1c6bf5f0c130c4da025c171c34',1,'Biblioteca']]],
  ['inter_5fvectors',['inter_vectors',['../_text_8cc.html#a1c53c2ee01d03417b3fb38ac094663ae',1,'Text.cc']]]
];
