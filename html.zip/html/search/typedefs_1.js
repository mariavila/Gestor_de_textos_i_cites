var searchData=
[
  ['mapc',['MAPC',['../_biblioteca_8cc.html#aaa77d31f5e620fd8bc28bc9f9e9cb19a',1,'MAPC():&#160;Biblioteca.cc'],['../_biblioteca_8hh.html#aaa77d31f5e620fd8bc28bc9f9e9cb19a',1,'MAPC():&#160;Biblioteca.hh']]],
  ['msi',['MSI',['../_taula_8cc.html#a82349b724fe1a24fc316703827325d32',1,'MSI():&#160;Taula.cc'],['../_taula_8hh.html#a82349b724fe1a24fc316703827325d32',1,'MSI():&#160;Taula.hh']]]
];
