var searchData=
[
  ['replace_5ffrase',['replace_frase',['../class_frase.html#a970c0bd222ec9cdb1e71b199edbf183a',1,'Frase']]],
  ['replace_5fstrings',['replace_strings',['../class_taula.html#a010eca43e7dfa498f779cec7590beaf1',1,'Taula']]],
  ['replace_5ftext',['replace_text',['../class_text.html#a8d678ff514c72a6953df83a8df155cf0',1,'Text']]],
  ['replace_5ftriat',['replace_triat',['../class_biblioteca.html#a60cede5a70370f121bc81e9fa8b51ed0',1,'Biblioteca']]]
];
