var searchData=
[
  ['taula',['Taula',['../class_taula.html',1,'']]],
  ['text',['Text',['../class_text.html',1,'']]]
];
