var searchData=
[
  ['llegir_5ffrase',['llegir_frase',['../class_frase.html#a90a9e5f8eb9e4d05a955a2373899fc2b',1,'Frase']]],
  ['llegir_5ftext',['llegir_text',['../class_text.html#a60eb7a72e4338aa0f90fb18854863708',1,'Text']]],
  ['llegir_5ftext_5fbiblio',['llegir_text_biblio',['../class_biblioteca.html#a0ac21a395597c832077ed7a6c43de14c',1,'Biblioteca']]]
];
