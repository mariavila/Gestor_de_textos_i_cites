var searchData=
[
  ['valor_5fiessim_5ffirst',['valor_iessim_first',['../class_frase.html#a6e6465ffe8ab4785e9458c01e098e8a2',1,'Frase']]],
  ['valor_5fiessim_5fsecond',['valor_iessim_second',['../class_frase.html#a8b39cd105da939116cefb5dafa7bcaa5',1,'Frase']]],
  ['ve',['VE',['../_text_8cc.html#a25ce99b4c3cb207869212e54b1837377',1,'VE():&#160;Text.cc'],['../_text_8hh.html#a25ce99b4c3cb207869212e54b1837377',1,'VE():&#160;Text.hh']]],
  ['vector_5faparicions_5ffrase',['vector_aparicions_frase',['../class_frase.html#af40d4e6bb28007727ef7df798dff9b83',1,'Frase']]],
  ['vf',['VF',['../_text_8cc.html#a62d60ee59506d6d392bcdb054c5f48ce',1,'VF():&#160;Text.cc'],['../_text_8hh.html#a62d60ee59506d6d392bcdb054c5f48ce',1,'VF():&#160;Text.hh']]],
  ['vp',['VP',['../_frase_8cc.html#a1343b4e3ec2d84c9c9e324e52b549da8',1,'VP():&#160;Frase.cc'],['../_frase_8hh.html#a1343b4e3ec2d84c9c9e324e52b549da8',1,'VP():&#160;Frase.hh']]],
  ['vpsd',['VPSD',['../_taula_8cc.html#a60e02ea83dacf4e2cb449785b32a5be0',1,'VPSD():&#160;Taula.cc'],['../_taula_8hh.html#a60e02ea83dacf4e2cb449785b32a5be0',1,'VPSD():&#160;Taula.hh']]],
  ['vpti',['VPTI',['../_biblioteca_8cc.html#a21e012d32b1a21b85351e4e47c80bc2d',1,'VPTI():&#160;Biblioteca.cc'],['../_biblioteca_8hh.html#a21e012d32b1a21b85351e4e47c80bc2d',1,'VPTI():&#160;Biblioteca.hh']]],
  ['vs',['VS',['../_text_8cc.html#aef59ba93d6d9b65e730b0a7f5e696acf',1,'Text.cc']]]
];
