var searchData=
[
  ['text_5fvalid',['text_valid',['../class_biblioteca.html#a9d0f237816a4c181bb8c29a71f0a9253',1,'Biblioteca']]],
  ['textos_5fbiblio',['textos_biblio',['../class_biblioteca.html#af5164bcce1f70a80a06d82f0b78c9f07',1,'Biblioteca']]],
  ['titol_5fdel_5ftext',['titol_del_text',['../class_text.html#a877866f5662b50ffecdb07185e69a031',1,'Text']]],
  ['triat',['triat',['../class_biblioteca.html#aa6e859bba67d97df2ac80da0ae4744f0',1,'Biblioteca']]]
];
