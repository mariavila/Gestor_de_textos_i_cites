var searchData=
[
  ['unir_5fvectors',['unir_vectors',['../_text_8cc.html#a46b0e13de0c0298c45df4d2ac7c678cb',1,'Text.cc']]]
];
