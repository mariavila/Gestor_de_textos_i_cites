var searchData=
[
  ['set_5fparaules_5ftext',['set_paraules_text',['../class_text.html#aed458c64898a0a4f394de7b701ea7f40',1,'Text']]]
];
