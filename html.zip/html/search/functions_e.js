var searchData=
[
  ['valor_5fiessim_5ffirst',['valor_iessim_first',['../class_frase.html#a6e6465ffe8ab4785e9458c01e098e8a2',1,'Frase']]],
  ['valor_5fiessim_5fsecond',['valor_iessim_second',['../class_frase.html#a8b39cd105da939116cefb5dafa7bcaa5',1,'Frase']]],
  ['vector_5faparicions_5ffrase',['vector_aparicions_frase',['../class_frase.html#af40d4e6bb28007727ef7df798dff9b83',1,'Frase']]]
];
