var searchData=
[
  ['frases_5fcontingut',['frases_contingut',['../class_text.html#adf36804f22e160b7f6e29da28bd8ee56',1,'Text']]],
  ['freq_5fstring',['freq_string',['../class_taula.html#a127a0044ad2bff8c9e19aae1263743ab',1,'Taula']]],
  ['freq_5ftext_5ftriat',['freq_text_triat',['../class_biblioteca.html#a2190f51cd038a875763243be4415393c',1,'Biblioteca']]]
];
